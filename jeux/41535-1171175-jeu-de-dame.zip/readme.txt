Jeu de dame-----------
Url     : http://codes-sources.commentcamarche.net/source/41535-jeu-de-dameAuteur  : cs_wizadDate    : 09/02/2021
Licence :
=========

Ce document intitul� � Jeu de dame � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Voici une version personelle du c&eacute;l&egrave;bre jeu de soci&eacute;t&eacut
e;.
<br />
<br />Comprend une interface graphique utilisant Tkinter, et int&ea
cute;grant la plupart des r&egrave;gles de ce jeu.
<br /><a name='conclusion'><
/a><h2> Conclusion : </h2>
<br />Il s'agit de mon premier code en python. Prog
rammer volontairement de mani&egrave;re proc&eacute;durale (il s'agissait d'un e
xercice dans le cadre de mes &eacute;tudes et la POO &eacute;tait interdite).
<
br />
<br />La seule r&egrave;gle n'&eacute;tant pas impl&eacute;menter (sauf s
i j'en oublie) est celle permettant les prises multiples.
